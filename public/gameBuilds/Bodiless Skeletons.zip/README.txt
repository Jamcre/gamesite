BODILESS SKELETONS
- This is the executable necessary to run the game

BODILESS SKELETONS.CONSOLE
- This is the Debug Tool for the Game

libgdsqlite DLL FILE
- This is the database file necessary for the game.
- PLEASE KEEP IN THE SAME DIRECTORY AS EXECUTABLE, WHEN RUNNING GAME